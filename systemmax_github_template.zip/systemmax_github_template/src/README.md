Código-fonte do projeto (Next.js + TypeScript)
