# Template de Repositório - Next.js + TypeScript

Este repositório é um template com padrões para:
- Gestão de projeto com GitHub Projects e Issue templates
- Pipeline com GitHub Actions e Environments protegidos
- Padrões de PR e branch protection para evidência de code review

## Scripts recomendados (package.json)
- `npm run build` - build do Next.js
- `npm run lint` - lint
- `npm run test` - testes unitários
