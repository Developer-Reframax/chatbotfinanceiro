# Requisitos do Projeto

Documente aqui os requisitos funcionais e não-funcionais. Utilize uma issue de tipo 'Levantamento de Requisitos' para rastrear quem solicitou, critérios de aceitação e anexos.
