# Plano de Testes

- Testes Unitários: executar `npm run test` (configurar coverage)
- Testes E2E: (ex.: Playwright / Cypress) - documentar cenários e evidências
- Testes de Performance: documentar ferramentas e resultados
- Registro de evidências: salvar logs em `docs/evidencias_auditoria.md`
