# Changelog

Registre mudanças importantes por versão.

## v0.1.0 - Inicial
- Estrutura inicial do projeto
