# Evidências para Auditoria

Liste os artefatos que comprovam cada etapa:
- Issues e templates preenchidos
- Pull Requests com revisões (comentários e aprovações)
- Logs do GitHub Actions (builds, testes, aprovações)
- Releases e changelog
